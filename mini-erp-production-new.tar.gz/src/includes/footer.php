<?php
/**
 * Footer Component
 * Standard footer for all pages
 */
?>
        </main>
        
        <footer>
            <p>&copy; 2025 Mini ERP System</p>
        </footer>
    </div>
</body>
</html>
-- Migration 005: Add customers and suppliers tables (fixed version)
-- Normalize customer and supplier data

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_code VARCHAR(20) UNIQUE,
    customer_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address_line1 VARCHAR(100),
    address_line2 VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(20),
    zip_code VARCHAR(20),
    country VARCHAR(50) DEFAULT 'USA',
    is_active BOOLEAN DEFAULT TRUE,
    payment_terms VARCHAR(50),
    credit_limit DECIMAL(12,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_customer_code (customer_code),
    INDEX idx_customer_name (customer_name),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Create suppliers table
CREATE TABLE IF NOT EXISTS suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_code VARCHAR(20) UNIQUE,
    supplier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address_line1 VARCHAR(100),
    address_line2 VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(20),
    zip_code VARCHAR(20),
    country VARCHAR(50) DEFAULT 'USA',
    is_active BOOLEAN DEFAULT TRUE,
    payment_terms VARCHAR(50),
    lead_time_days INT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_supplier_code (supplier_code),
    INDEX idx_supplier_name (supplier_name),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Insert existing customers from products table
INSERT IGNORE INTO customers (customer_name, customer_code, created_by)
SELECT DISTINCT 
    customer_name,
    CONCAT('CUST', LPAD(ROW_NUMBER() OVER (ORDER BY customer_name), 3, '0')) as customer_code,
    1 as created_by
FROM products 
WHERE customer_name IS NOT NULL 
AND customer_name != '';

-- Insert existing suppliers from materials table  
INSERT IGNORE INTO suppliers (supplier_name, supplier_code, created_by)
SELECT DISTINCT 
    supplier_name,
    CONCAT('SUPP', LPAD(ROW_NUMBER() OVER (ORDER BY supplier_name), 3, '0')) as supplier_code,
    1 as created_by
FROM materials 
WHERE supplier_name IS NOT NULL 
AND supplier_name != '';

-- Add customer_id column to products if not exists
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS customer_id INT AFTER customer_part_number;

-- Add supplier_id column to materials if not exists  
ALTER TABLE materials 
ADD COLUMN IF NOT EXISTS supplier_id INT AFTER supplier_name;

-- Update foreign key references
UPDATE products p 
JOIN customers c ON p.customer_name = c.customer_name 
SET p.customer_id = c.id 
WHERE p.customer_name IS NOT NULL AND p.customer_id IS NULL;

UPDATE materials m 
JOIN suppliers s ON m.supplier_name = s.supplier_name 
SET m.supplier_id = s.id 
WHERE m.supplier_name IS NOT NULL AND m.supplier_id IS NULL;
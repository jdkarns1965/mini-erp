-- Manufacturing ERP Database Schema
-- Version 2.0 - Complete Manufacturing Traceability System

-- Users table for authentication and role-based access
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'supervisor', 'material_handler', 'quality_inspector', 'viewer') NOT NULL DEFAULT 'viewer',
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_role (role)
);

-- Materials master for raw materials and concentrates
CREATE TABLE IF NOT EXISTS materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    material_code VARCHAR(50) NOT NULL UNIQUE,
    material_name VARCHAR(100) NOT NULL,
    material_type ENUM('base_resin', 'color_concentrate', 'rework', 'component') NOT NULL,
    supplier_name VARCHAR(100),
    unit_of_measure ENUM('lbs', 'kg', 'oz', 'ea', 'ft', 'in') DEFAULT 'lbs',
    unit_cost DECIMAL(10,4) DEFAULT 0.00,
    reorder_point INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_material_code (material_code),
    INDEX idx_material_type (material_type),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Current inventory with lot tracking and FIFO
CREATE TABLE IF NOT EXISTS inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    material_id INT NOT NULL,
    lot_number VARCHAR(50) NOT NULL,
    supplier_lot_number VARCHAR(50),
    quantity_received DECIMAL(10,3) NOT NULL,
    quantity_available DECIMAL(10,3) NOT NULL,
    unit_cost DECIMAL(10,4) DEFAULT 0.00,
    received_date DATE NOT NULL,
    expiration_date DATE NULL,
    location VARCHAR(50),
    status ENUM('available', 'reserved', 'hold', 'consumed') DEFAULT 'available',
    received_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_material_fifo (material_id, received_date),
    INDEX idx_lot_number (lot_number),
    INDEX idx_status (status),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (received_by) REFERENCES users(id),
    UNIQUE KEY unique_material_lot (material_id, lot_number)
);

-- Products master for manufactured items
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_code VARCHAR(50) NOT NULL UNIQUE,
    product_name VARCHAR(100) NOT NULL,
    customer_name VARCHAR(100),
    customer_part_number VARCHAR(50),
    product_category VARCHAR(50),
    target_weight DECIMAL(8,3),
    cycle_time INT, -- seconds
    cavity_count INT DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    engineering_drawing_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_product_code (product_code),
    INDEX idx_customer (customer_name),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Recipes for material formulations
CREATE TABLE IF NOT EXISTS recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    version VARCHAR(10) NOT NULL DEFAULT '1.0',
    base_material_id INT NOT NULL,
    concentrate_material_id INT,
    concentrate_percentage DECIMAL(5,2),
    is_approved BOOLEAN DEFAULT FALSE,
    approved_by_supervisor INT NULL,
    approved_by_quality INT NULL,
    approval_date DATETIME NULL,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_product_recipe (product_id, is_active),
    INDEX idx_approval_status (is_approved),
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (base_material_id) REFERENCES materials(id),
    FOREIGN KEY (concentrate_material_id) REFERENCES materials(id),
    FOREIGN KEY (approved_by_supervisor) REFERENCES users(id),
    FOREIGN KEY (approved_by_quality) REFERENCES users(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    UNIQUE KEY unique_product_version (product_id, version)
);

-- Production jobs/work orders
CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_number VARCHAR(50) NOT NULL UNIQUE,
    product_id INT NOT NULL,
    recipe_id INT NOT NULL,
    target_quantity INT NOT NULL,
    produced_quantity INT DEFAULT 0,
    scrap_quantity INT DEFAULT 0,
    status ENUM('planned', 'in_progress', 'completed', 'on_hold', 'cancelled') DEFAULT 'planned',
    priority ENUM('low', 'normal', 'high', 'rush') DEFAULT 'normal',
    scheduled_date DATE,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    operator_id INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_job_number (job_number),
    INDEX idx_status (status),
    INDEX idx_scheduled_date (scheduled_date),
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (recipe_id) REFERENCES recipes(id),
    FOREIGN KEY (operator_id) REFERENCES users(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Material usage tracking for jobs
CREATE TABLE IF NOT EXISTS material_usage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    inventory_id INT NOT NULL,
    quantity_used DECIMAL(10,3) NOT NULL,
    usage_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    recorded_by INT,
    INDEX idx_job_materials (job_id),
    INDEX idx_inventory_usage (inventory_id),
    FOREIGN KEY (job_id) REFERENCES jobs(id),
    FOREIGN KEY (inventory_id) REFERENCES inventory(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id)
);

-- Quality control events and decisions
CREATE TABLE IF NOT EXISTS quality_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    event_type ENUM('recipe_approval', 'production_stop', 'quality_hold', 'scrap_decision', 'rework_approval') NOT NULL,
    event_description TEXT NOT NULL,
    decision ENUM('approved', 'rejected', 'rework', 'scrap', 'hold') NOT NULL,
    decided_by INT NOT NULL,
    supervisor_approval INT NULL,
    quality_approval INT NULL,
    event_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolution_notes TEXT,
    INDEX idx_job_events (job_id),
    INDEX idx_event_type (event_type),
    INDEX idx_event_timestamp (event_timestamp),
    FOREIGN KEY (job_id) REFERENCES jobs(id),
    FOREIGN KEY (decided_by) REFERENCES users(id),
    FOREIGN KEY (supervisor_approval) REFERENCES users(id),
    FOREIGN KEY (quality_approval) REFERENCES users(id)
);

-- Audit log for ISO compliance
CREATE TABLE IF NOT EXISTS audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_actions (user_id, timestamp),
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_timestamp (timestamp),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Session management for security
CREATE TABLE IF NOT EXISTS user_sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id INT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    INDEX idx_user_sessions (user_id),
    INDEX idx_expires (expires_at),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
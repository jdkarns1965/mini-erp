-- Migration 003: Fix column name inconsistencies
-- Run this on existing databases to align with current code

-- Add missing columns to products table if they don't exist
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS product_name VARCHAR(100) AFTER product_code,
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- Update products table to match expected schema
UPDATE products SET product_name = product_code WHERE product_name IS NULL;

-- Ensure materials table has is_active column
ALTER TABLE materials 
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE AFTER reorder_point;

-- Note: inventory table schema is already correct with quantity_received and quantity_available columns
-- Manual fix for customers and suppliers normalization
-- Run this directly in phpMyAdmin or MySQL command line

-- Check if customers table exists, if not create it
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_code VARCHAR(20) UNIQUE,
    customer_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address_line1 VARCHAR(100),
    address_line2 VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(20),
    zip_code VARCHAR(20),
    country VARCHAR(50) DEFAULT 'USA',
    is_active BOOLEAN DEFAULT TRUE,
    payment_terms VARCHAR(50),
    credit_limit DECIMAL(12,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT DEFAULT 1
);

-- Check if suppliers table exists, if not create it
CREATE TABLE IF NOT EXISTS suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_code VARCHAR(20) UNIQUE,
    supplier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address_line1 VARCHAR(100),
    address_line2 VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(20),
    zip_code VARCHAR(20),
    country VARCHAR(50) DEFAULT 'USA',
    is_active BOOLEAN DEFAULT TRUE,
    payment_terms VARCHAR(50),
    lead_time_days INT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT DEFAULT 1
);

-- Insert sample customers and suppliers from existing data
INSERT IGNORE INTO customers (customer_name, customer_code, created_by)
SELECT DISTINCT 
    customer_name,
    CONCAT('CUST', LPAD(@row_number:=@row_number+1, 3, '0')) as customer_code,
    1 as created_by
FROM products, (SELECT @row_number:=0) r
WHERE customer_name IS NOT NULL 
AND customer_name != '';

INSERT IGNORE INTO suppliers (supplier_name, supplier_code, created_by)
SELECT DISTINCT 
    supplier_name,
    CONCAT('SUPP', LPAD(@row_number2:=@row_number2+1, 3, '0')) as supplier_code,
    1 as created_by
FROM materials, (SELECT @row_number2:=0) r
WHERE supplier_name IS NOT NULL 
AND supplier_name != '';

-- Update foreign key references if columns exist
UPDATE products p 
JOIN customers c ON p.customer_name = c.customer_name 
SET p.customer_id = c.id 
WHERE p.customer_name IS NOT NULL;

UPDATE materials m 
JOIN suppliers s ON m.supplier_name = s.supplier_name 
SET m.supplier_id = s.id 
WHERE m.supplier_name IS NOT NULL;
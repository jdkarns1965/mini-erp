-- Migration 004: Add customers and suppliers tables
-- Normalize customer and supplier data

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_code VARCHAR(20) UNIQUE,
    customer_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address_line1 VARCHAR(100),
    address_line2 VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(20),
    zip_code VARCHAR(20),
    country VARCHAR(50) DEFAULT 'USA',
    is_active BOOLEAN DEFAULT TRUE,
    payment_terms VARCHAR(50),
    credit_limit DECIMAL(12,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_customer_code (customer_code),
    INDEX idx_customer_name (customer_name),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Create suppliers table
CREATE TABLE IF NOT EXISTS suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_code VARCHAR(20) UNIQUE,
    supplier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address_line1 VARCHAR(100),
    address_line2 VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(20),
    zip_code VARCHAR(20),
    country VARCHAR(50) DEFAULT 'USA',
    is_active BOOLEAN DEFAULT TRUE,
    payment_terms VARCHAR(50),
    lead_time_days INT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_supplier_code (supplier_code),
    INDEX idx_supplier_name (supplier_name),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Insert existing customers from products table
INSERT IGNORE INTO customers (customer_name, customer_code, created_by)
SELECT DISTINCT 
    customer_name,
    UPPER(LEFT(REPLACE(customer_name, ' ', ''), 8)) as customer_code,
    1 as created_by
FROM products 
WHERE customer_name IS NOT NULL 
AND customer_name != '';

-- Insert existing suppliers from materials table
INSERT IGNORE INTO suppliers (supplier_name, supplier_code, created_by)
SELECT DISTINCT 
    supplier_name,
    UPPER(LEFT(REPLACE(supplier_name, ' ', ''), 8)) as supplier_code,
    1 as created_by
FROM materials 
WHERE supplier_name IS NOT NULL 
AND supplier_name != '';

-- Add foreign key columns to existing tables (without constraints first)
ALTER TABLE products 
ADD COLUMN customer_id INT AFTER customer_part_number,
ADD INDEX idx_customer_id (customer_id);

ALTER TABLE materials 
ADD COLUMN supplier_id INT AFTER supplier_name,
ADD INDEX idx_supplier_id (supplier_id);

-- Update foreign key references
UPDATE products p 
JOIN customers c ON p.customer_name = c.customer_name 
SET p.customer_id = c.id 
WHERE p.customer_name IS NOT NULL;

UPDATE materials m 
JOIN suppliers s ON m.supplier_name = s.supplier_name 
SET m.supplier_id = s.id 
WHERE m.supplier_name IS NOT NULL;

-- Add foreign key constraints after data is populated
ALTER TABLE products 
ADD FOREIGN KEY (customer_id) REFERENCES customers(id);

ALTER TABLE materials 
ADD FOREIGN KEY (supplier_id) REFERENCES suppliers(id);

-- Note: Keep old columns for now, remove in future migration after testing